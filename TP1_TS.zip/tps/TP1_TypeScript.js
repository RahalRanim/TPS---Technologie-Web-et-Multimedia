var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// Exercice 2: Types de base
console.log("************ Exercice 2: Types de base ****************");
// 1°) Déclarationn des variables
var nom = "Ranim";
var age = 22;
var isAdmin = true;
console.log("Name: ".concat(nom, ", Age: ").concat(age, ", Is Admin: ").concat(isAdmin));
// 2°) Déclaration d'un tableau des nombres
var scores = [1, 2, 3, 4, 5];
console.log("Tableau des scores:", scores);
// 3°) Déclaration d'un tuple
var student = ["Ranim", 3];
console.log("Tuple étudiant:", student);
// 4°) Déclaration d'une énumération
var Role;
(function (Role) {
    Role[Role["User"] = 0] = "User";
    Role[Role["Admin"] = 1] = "Admin";
    Role[Role["SuperAdmin"] = 2] = "SuperAdmin";
})(Role || (Role = {}));
var myRole = Role.Admin;
console.log("Mon rôle est :", Role[myRole]);
// Exercice 3: Types avancés
console.log("************ Exercice 3: Types avancés ****************");
// 1°) Déclaration d'une union de types
var id;
var person = {
    name: "Ranim",
    age: 22
};
console.log("Personne:", person);
// 4°) Variable unknown + assertion de typeDéclaration d'un alias
var unknownValue = "Ranim Rahal";
var len = unknownValue.length;
console.log("Longueur :", len);
// Exercice 4: Objects & Interfaces
console.log("************ Exercice 4: Objects & Interfaces ****************");
// 2°) Création d'un objet 
var user1 = {
    id: 1,
    name: "Ranim",
    email: "ranim@example.com",
    isAdmin: false
};
console.log("Utilisateur 1:", user1);
var admin1 = {
    id: 2,
    name: "Super Admin",
    isAdmin: true,
    permissions: ["read", "write", "delete"]
};
console.log("Admin 1:", admin1);
// Exercice 5 : Fonctions
console.log("************ Exercice 5 : Fonctions ****************");
// 1°) Fonction add
function add(a, b) {
    return a + b;
}
console.log("Addition 5 + 10:", add(5, 10));
// 2°) Fonction avec paramètre optionnel
function greet(name, age) {
    if (age !== undefined) {
        console.log("Bonjour ".concat(name, ", tu as ").concat(age, " ans."));
    }
    else {
        console.log("Bonjour ".concat(name, "!"));
    }
}
greet("Ranim", 22);
greet("Ranim");
// 3°) Fonction avec paramètre par défaut
function power(base, exp) {
    if (exp === void 0) { exp = 2; }
    return Math.pow(base, exp);
}
console.log("2 puissance 3:", power(2, 3));
console.log("3 puissance 2 (par défaut):", power(3));
function combine(a, b) {
    return a + b;
}
console.log(combine(2, 3));
console.log(combine("Hello ", "Ranim"));
// Exercice 6 : POO
console.log("************ Exercice 6 : POO ****************");
// 1°) Déclaration d'une classe Person
var Person = /** @class */ (function () {
    function Person(name, age) {
        this.name = name;
        this.age = age;
    }
    Person.prototype.greet = function () {
        console.log("Bonjour, je m'appelle ".concat(this.name, " et j'ai ").concat(this.age, " ans."));
    };
    return Person;
}());
// 2°) Création d'une instance de Person
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student(name, age, school) {
        var _this = _super.call(this, name, age) || this; // Appel au constructeur parent
        _this.school = school;
        return _this;
    }
    Student.prototype.study = function () {
        console.log("".concat(this.name, " \u00E9tudie \u00E0 ").concat(this.school, "."));
    };
    return Student;
}(Person));
var student1 = new Student("Ranim", 22, "Faculté des Sciences de Tunis");
student1.greet();
student1.study();
// 3°) Déclaration d'une classe abstraite
var Shape = /** @class */ (function () {
    function Shape() {
    }
    return Shape;
}());
var Circle = /** @class */ (function (_super) {
    __extends(Circle, _super);
    function Circle(radius) {
        var _this = _super.call(this) || this;
        _this.radius = radius;
        return _this;
    }
    Circle.prototype.area = function () {
        return Math.PI * this.radius * this.radius;
    };
    return Circle;
}(Shape));
var circle1 = new Circle(5);
console.log("Aire du cercle de rayon 5:", circle1.area());
var Rectangle = /** @class */ (function (_super) {
    __extends(Rectangle, _super);
    function Rectangle(width, height) {
        var _this = _super.call(this) || this;
        _this.width = width;
        _this.height = height;
        return _this;
    }
    Rectangle.prototype.area = function () {
        return this.width * this.height;
    };
    return Rectangle;
}(Shape));
var rectangle1 = new Rectangle(4, 6);
console.log("Aire du rectangle 4x6:", rectangle1.area());
var Car = /** @class */ (function () {
    function Car(model) {
        this.model = model;
    }
    Car.prototype.drive = function () {
        console.log("La voiture ".concat(this.model, " est en train de rouler."));
    };
    return Car;
}());
var car1 = new Car("Toyota");
car1.drive();
// Exercice 7 : Génériques
console.log("************ Exercice 7 : Génériques ****************");
// 1°) Fonction générique : identity
function identity(value) {
    return value;
}
console.log(identity(10));
console.log(identity("Ranim"));
// 2°) Fonction générique : getFirst
function getFirst(arr) {
    return arr[0];
}
console.log(getFirst([10, 20, 30])); // 10
console.log(getFirst(["a", "b"])); // "a"
// 3°) Fonction générique : Repository
var Repository = /** @class */ (function () {
    function Repository() {
        this.items = [];
    }
    Repository.prototype.add = function (item) {
        this.items.push(item);
    };
    Repository.prototype.remove = function (item) {
        this.items = this.items.filter(function (i) { return i !== item; });
    };
    Repository.prototype.getAll = function () {
        return this.items;
    };
    return Repository;
}());
var numberRepo = new Repository();
numberRepo.add(5);
numberRepo.add(10);
numberRepo.remove(5);
console.log(numberRepo.getAll());
// Exemple :
var response1 = {
    data: "Succès"
};
var response2 = {
    data: [1, 2, 3],
    error: "Aucune donnée trouvée"
};
console.log("Response 1:", response1);
console.log("Response 2:", response2);
