//import { add } from "./math";

//console.log(add(5, 3)); 

import { add, subtract } from "./index";
import type { User } from "./types";

console.log(add(10, 5));
console.log(subtract(10, 5));



const u: User = {
    id: 1,
    name: "Ranim"
};

console.log(u);
