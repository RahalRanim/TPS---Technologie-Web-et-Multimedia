// Exercice 2: Types de base
console.log("************ Exercice 2: Types de base ****************");
    // 1°) Déclarationn des variables
let nom: string = "Ranim";
let age: number = 22;
let isAdmin: boolean = true;
console.log(`Name: ${nom}, Age: ${age}, Is Admin: ${isAdmin}`);
    // 2°) Déclaration d'un tableau des nombres
let scores: number[] = [1, 2, 3, 4, 5];
console.log("Tableau des scores:", scores);
    // 3°) Déclaration d'un tuple
let student: [string, number] = ["Ranim", 3];
console.log("Tuple étudiant:", student);
    // 4°) Déclaration d'une énumération
enum Role {
    User,
    Admin,
    SuperAdmin
}
let myRole: Role = Role.Admin;
console.log("Mon rôle est :", Role[myRole]);

// Exercice 3: Types avancés
console.log("************ Exercice 3: Types avancés ****************");
    // 1°) Déclaration d'une union de types
let id: number | string;
    // 2°) Création de deux types
type A = {
    name: string;
};
type B = {
    age: number;
};
type C = A & B; // Intersection = doit avoir *à la fois* name et age
let person: C = {
    name: "Ranim",
    age: 22
};
console.log("Personne:", person);
    // 3°) Déclaration d'un alias
type Status = "pending" | "done" | "canceled";
    // 4°) Variable unknown + assertion de typeDéclaration d'un alias
let unknownValue: unknown = "Ranim Rahal";
let len = (unknownValue as string).length;
console.log("Longueur :", len);

// Exercice 4: Objects & Interfaces
console.log("************ Exercice 4: Objects & Interfaces ****************");
    // 1°) Déclaration d'une interface
interface User {
    id: number;
    name: string;
    email?: string;
    readonly isAdmin: boolean;
}
    // 2°) Création d'un objet 
const user1: User = {
    id: 1,
    name: "Ranim",
    email: "ranim@example.com",
    isAdmin: false
};
console.log("Utilisateur 1:", user1);
    // 3°) Héritage d'interface
interface Admin extends User {
    permissions: string[];
}

const admin1: Admin = {
    id: 2,
    name: "Super Admin",
    isAdmin: true,
    permissions: ["read", "write", "delete"]
};
console.log("Admin 1:", admin1);

// Exercice 5 : Fonctions
console.log("************ Exercice 5 : Fonctions ****************");
    // 1°) Fonction add
function add(a: number, b: number): number {
    return a + b;
}
console.log("Addition 5 + 10:", add(5, 10));
    // 2°) Fonction avec paramètre optionnel
function greet(name: string, age?: number): void {
    if (age !== undefined) {
        console.log(`Bonjour ${name}, tu as ${age} ans.`);
    } else {
        console.log(`Bonjour ${name}!`);
    }
}
greet("Ranim", 22);
greet("Ranim");
    // 3°) Fonction avec paramètre par défaut
function power(base: number, exp: number = 2): number {
    return base ** exp;
}
console.log("2 puissance 3:", power(2, 3));
console.log("3 puissance 2 (par défaut):", power(3));
    // 4°) fonction combine avec surcharge
function combine(a: number, b: number): number;
function combine(a: string, b: string): string;
function combine(a: any, b: any): any {
    return a + b;
}
console.log(combine(2, 3));
console.log(combine("Hello ", "Ranim")); 

// Exercice 6 : POO
console.log("************ Exercice 6 : POO ****************");
    // 1°) Déclaration d'une classe Person
class Person {
    name: string;
    age: number;

    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
    }

    greet(): void {
        console.log(`Bonjour, je m'appelle ${this.name} et j'ai ${this.age} ans.`);
    }
}
    // 2°) Création d'une instance de Person
class Student extends Person {
    school: string;

    constructor(name: string, age: number, school: string) {
        super(name, age);   // Appel au constructeur parent
        this.school = school;
    }

    study(): void {
        console.log(`${this.name} étudie à ${this.school}.`);
    }
}
const student1 = new Student("Ranim", 22, "Faculté des Sciences de Tunis");
student1.greet();
student1.study();
    // 3°) Déclaration d'une classe abstraite
abstract class Shape {
    abstract area(): number;  // Méthode abstraite
}
class Circle extends Shape {
    radius: number;

    constructor(radius: number) {
        super();
        this.radius = radius;
    }

    area(): number {
        return Math.PI * this.radius * this.radius;
    }
}
const circle1 = new Circle(5);
console.log("Aire du cercle de rayon 5:", circle1.area());
class Rectangle extends Shape {
    width: number;
    height: number;

    constructor(width: number, height: number) {
        super();
        this.width = width;
        this.height = height;
    }

    area(): number {
        return this.width * this.height;
    }
}
const rectangle1 = new Rectangle(4, 6);
console.log("Aire du rectangle 4x6:", rectangle1.area());
    // 4°) Interface Drivable + classe Car
interface Drivable {
    drive(): void;
}
class Car implements Drivable {
    model: string;

    constructor(model: string) {
        this.model = model;
    }

    drive(): void {
        console.log(`La voiture ${this.model} est en train de rouler.`);
    }
}
const car1 = new Car("Toyota");
car1.drive();  

// Exercice 7 : Génériques
console.log("************ Exercice 7 : Génériques ****************");
    // 1°) Fonction générique : identity
function identity<T>(value: T): T {
    return value;
}
console.log(identity<number>(10));       
console.log(identity<string>("Ranim"));  
    // 2°) Fonction générique : getFirst
function getFirst<T>(arr: T[]): T {
    return arr[0];
}
console.log(getFirst<number>([10, 20, 30]));  // 10
console.log(getFirst<string>(["a", "b"]));    // "a"
    // 3°) Fonction générique : Repository
class Repository<T> {
    private items: T[] = [];

    add(item: T): void {
        this.items.push(item);
    }

    remove(item: T): void {
        this.items = this.items.filter(i => i !== item);
    }

    getAll(): T[] {
        return this.items;
    }
}
const numberRepo = new Repository<number>();
numberRepo.add(5);
numberRepo.add(10);
numberRepo.remove(5);
console.log(numberRepo.getAll());  
    // 4°) Interface générique 
interface ApiResponse<T> {
    data: T;
    error?: string;
}

// Exemple :
const response1: ApiResponse<string> = {
    data: "Succès"
};

const response2: ApiResponse<number[]> = {
    data: [1, 2, 3],
    error: "Aucune donnée trouvée"
};
console.log("Response 1:", response1);
console.log("Response 2:", response2);
